# $wikipage  
$date
$datetime
$time

