import os
os.system('python3 -m pip install flask==1.1.2 flask_socketio==4.3.0 fuzzywuzzy==0.18.0 pathtools==0.1.2 watchdog==0.10.3 python-socketio==4.3.1 python-engineio==3.13.2')